-- Existing profiles table/trigger থাকলে আগে review করুন, duplicate trigger তৈরি করবেন না.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text,
 referral_code text unique,
 referred_by text,
 created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
drop policy if exists "Members can read own profile" on public.profiles;
create policy "Members can read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create or replace function public.make_referral_code() returns text language sql as $$
 select 'EB' || upper(substr(encode(gen_random_bytes(6),'hex'),1,10));
$$;
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,display_name,referral_code,referred_by)
 values(new.id,coalesce(new.raw_user_meta_data->>'display_name',''),public.make_referral_code(),nullif(new.raw_user_meta_data->>'referral_code',''))
 on conflict(id) do nothing;
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
