EarnBD Ads Member Portal
1. index.html-এ Supabase Project URL এবং Publishable Key বসান। sb_secret_ কখনো বসাবেন না।
2. Supabase SQL Editor-এ supabase-setup.sql চালানোর আগে existing profiles table/trigger/policy review করুন।
3. GitHub root-এ index.html পুরোনো ফাইলের বদলে আপলোড করুন। Cloudflare Pages deploy করুন।
এই সংস্করণে signup/login, profile, referral page, wallet display placeholder আছে। টাকা জমা/আয়/উত্তোলন/অ্যাডমিন নেই।